import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const FILE_PATH = path.join(DATA_DIR, 'users.json');

function ensureFile() {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(FILE_PATH)) {
        fs.writeFileSync(FILE_PATH, JSON.stringify([], null, 2), 'utf8');
    }
}

export function getAllUsers() {
    ensureFile();
    try {
        const raw = fs.readFileSync(FILE_PATH, 'utf8');
        return JSON.parse(raw) || [];
    } catch {
        return [];
    }
}

export function saveUsers(users) {
    ensureFile();
    fs.writeFileSync(FILE_PATH, JSON.stringify(users, null, 2), 'utf8');
}

export function getUserStatus(uid, email) {
    const users = getAllUsers();
    const cleanUid = String(uid || "").trim().toLowerCase();
    const cleanEmail = String(email || "").trim().toLowerCase();

    if (!cleanUid && !cleanEmail) return { status: "active", disabled: false };

    const user = users.find(u =>
        (cleanUid && u.uid && u.uid.toLowerCase() === cleanUid) ||
        (cleanUid && u.id && u.id.toLowerCase() === cleanUid) ||
        (cleanEmail && u.email && u.email.toLowerCase() === cleanEmail)
    );

    if (!user) return { status: "active", disabled: false };
    return {
        status: user.status || "active",
        disabled: user.status === "disabled",
        user
    };
}

export function syncUser(userData) {
    if (!userData || (!userData.uid && !userData.email)) {
        throw new Error("Invalid user data for sync");
    }

    const users = getAllUsers();
    const cleanUid = String(userData.uid || "").trim();
    const cleanEmail = String(userData.email || "").trim().toLowerCase();

    let existing = users.find(u => (cleanUid && u.uid === cleanUid) || (cleanEmail && u.email.toLowerCase() === cleanEmail));

    if (existing) {
        if (userData.displayName) existing.displayName = userData.displayName;
        if (userData.photoURL) existing.photoURL = userData.photoURL;
        if (userData.providerId) existing.providerId = userData.providerId;
        existing.lastLoginAt = new Date().toISOString();
        saveUsers(users);
        return existing;
    } else {
        const newUser = {
            id: cleanUid || "usr_" + Date.now(),
            uid: cleanUid || "usr_" + Date.now(),
            email: cleanEmail,
            displayName: userData.displayName || cleanEmail.split('@')[0] || "User",
            photoURL: userData.photoURL || null,
            providerId: userData.providerId || "google.com",
            plan: userData.plan || "free",
            status: "active",
            createdAt: new Date().toISOString(),
            lastLoginAt: new Date().toISOString()
        };
        users.unshift(newUser);
        saveUsers(users);
        return newUser;
    }
}

export function deleteUser(userId) {
    let users = getAllUsers();
    const initialLen = users.length;
    users = users.filter(u => u.id !== userId && u.uid !== userId);
    saveUsers(users);
    return true;
}

export async function deleteAllUsers() {
    saveUsers([]);
    try {
        const { db } = await import("../config/firebase.js");
        if (db) {
            const snapshot = await db.collection("users").get();
            if (!snapshot.empty) {
                const batch = db.batch();
                snapshot.docs.forEach(doc => {
                    batch.delete(doc.ref);
                });
                await batch.commit();
            }
        }
    } catch (e) {
        console.warn("[USER STORAGE] Delete all Firestore users notice:", e);
    }
    return true;
}

export function toggleUserStatus(userId) {
    const users = getAllUsers();
    const user = users.find(u => u.id === userId || u.uid === userId);
    if (!user) throw new Error("User not found");

    const isSuspended = user.locked === true || user.status === "SUSPENDED" || user.status === "disabled";
    if (isSuspended) {
        user.status = "active";
        user.locked = false;
        user.suspensionReason = null;
    } else {
        user.status = "disabled";
        user.locked = true;
        user.suspensionReason = "Manually suspended by Admin";
    }

    saveUsers(users);

    try {
        import("../config/firebase.js").then(({ db }) => {
            if (db) {
                db.collection("users").doc(userId).set({
                    locked: !isSuspended,
                    status: isSuspended ? "ACTIVE" : "SUSPENDED",
                    suspensionReason: isSuspended ? null : "Manually suspended by Admin"
                }, { merge: true }).catch(() => {});

                if (user.email) {
                    const cleanEmail = String(user.email).trim().toLowerCase();
                    db.collection("users").where("email", "==", cleanEmail).get().then(snap => {
                        if (!snap.empty) {
                            snap.docs.forEach(doc => {
                                doc.ref.set({
                                    locked: !isSuspended,
                                    status: isSuspended ? "ACTIVE" : "SUSPENDED",
                                    suspensionReason: isSuspended ? null : "Manually suspended by Admin"
                                }, { merge: true }).catch(() => {});
                            });
                        }
                    }).catch(() => {});
                }
            }
        }).catch(() => {});
    } catch (e) {}

    return user;
}

export function updateUserSuspension(userId, locked, status, reason) {
    const users = getAllUsers();
    const cleanId = String(userId || "").trim();
    const user = users.find(u => u.id === cleanId || u.uid === cleanId);
    if (user) {
        user.locked = Boolean(locked);
        user.status = status;
        user.suspensionReason = reason || null;
        saveUsers(users);
    }
}

export function updateUserSuspensionByEmail(email, locked, status, reason) {
    const users = getAllUsers();
    const cleanEmail = String(email || "").trim().toLowerCase();
    if (!cleanEmail) return;
    const user = users.find(u => u.email && u.email.toLowerCase() === cleanEmail);
    if (user) {
        user.locked = Boolean(locked);
        user.status = status;
        user.suspensionReason = reason || null;
        saveUsers(users);
    }
}
